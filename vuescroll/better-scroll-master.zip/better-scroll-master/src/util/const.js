export const DIRECTION_UP = 1
export const DIRECTION_DOWN = -1
export const DIRECTION_LEFT = 1
export const DIRECTION_RIGHT = -1

export const PROBE_DEBOUNCE = 1
export const PROBE_NORMAL = 2
export const PROBE_REALTIME = 3
